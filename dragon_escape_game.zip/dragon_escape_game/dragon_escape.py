import pygame
import random
import os
import json
from PIL import Image

# Initialize
pygame.init()
WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Dino Escape")
clock = pygame.time.Clock()
FPS = 60

# Colors
SKY = (135, 206, 235)
GREEN = (34, 200, 34)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)

# Asset paths
ASSETS = "assets"
castle_img = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "castle.png")), (100, 100))
dragon_img = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "dragon.png")), (80, 60))
fireball_img = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "fireball.png")), (30, 30))
coin_img = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "coin.png")), (30, 30))
heart_full = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "heart_full.png")), (30, 30))
heart_empty = pygame.transform.scale(pygame.image.load(os.path.join(ASSETS, "heart_empty.png")), (30, 30))

# Fonts
font = pygame.font.SysFont(None, 40)
big_font = pygame.font.SysFont(None, 72)

# Fireball timer
FIREBALL_TIMER = pygame.USEREVENT + 1
pygame.time.set_timer(FIREBALL_TIMER, 2500)  # Fireballs less frequent

# Game state
game_active = False
game_over = False
win = False

# High score
high_score_file = "highscore.json"
if os.path.exists(high_score_file):
    with open(high_score_file, "r") as f:
        high_score = json.load(f).get("score", 0)
else:
    high_score = 0

# Buttons
play_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 30, 200, 60)

# Dino physics
gravity = 0.8
jump_strength = -15
double_jump_strength = -25
dino_y_velocity = 0
jumps = 0
lives = 3
score = 0

ground_y = HEIGHT - 30

# Load GIF frames
def load_gif_frames(gif_path):
    img = Image.open(gif_path)
    frames = []
    try:
        while True:
            frame = img.convert("RGBA")
            frame = pygame.image.fromstring(frame.tobytes(), frame.size, frame.mode)
            frame = pygame.transform.scale(frame, (130, 110))
            frames.append(frame)
            img.seek(img.tell() + 1)
    except EOFError:
        pass
    return frames

dino_frames = load_gif_frames(os.path.join(ASSETS, "dinosaur_run.gif"))
dino_frame_index = 0
frame_timer = 0

# Game positions
dino_world_x = 50
camera_x = 0
dino_rect = dino_frames[0].get_rect(topleft=(100, ground_y - 110))

castle_distance = 10000  # 1 km = 10,000 px
castle_rect = castle_img.get_rect(midbottom=(castle_distance, HEIGHT - 30))

dragon_list = []
fireballs = []
coins = []

# Speed boost
speed_boost_zones = []
speed_boost_active = False
boost_speed = 10
base_speed = 6
current_speed = base_speed

def reset_game():
    global dino_rect, dragon_list, fireballs, coins, lives, score, dino_y_velocity, jumps
    global game_over, win, castle_rect, dino_world_x, camera_x, speed_boost_zones
    dino_world_x = 50
    camera_x = 0
    dino_rect.topleft = (100, ground_y - dino_rect.height)
    dragon_list = []
    fireballs.clear()
    coins.clear()
    lives = 3
    score = 0
    dino_y_velocity = 0
    jumps = 0
    game_over = False
    win = False
    castle_rect.midbottom = (castle_distance, HEIGHT - 30)

    # Dragons
    num_dragons = 16  # Reduced by 1
    last_x = 600
    for _ in range(num_dragons):
        x = last_x + random.randint(500, 600)
        y = random.randint(60, 180)
        dragon_list.append(pygame.Rect(x, y, 80, 60))
        last_x = x

        coin_x = x + random.randint(100, 300)
        coin_y = random.randint(250, HEIGHT - 150)
        coins.append(pygame.Rect(coin_x, coin_y, 30, 30))

    # Speed boost zones (1 or 2 zones, each 200px = 20m)
    speed_boost_zones.clear()
    num_boosts = random.choice([1, 2])
    for _ in range(num_boosts):
        x = random.randint(1000, castle_distance - 1000)
        speed_boost_zones.append(pygame.Rect(x, ground_y - 20, 400, 20))

def draw_hearts():
    for i in range(3):
        icon = heart_full if i < lives else heart_empty
        screen.blit(icon, (10 + i * 35, 10))

def draw_menu():
    screen.fill(SKY)
    title = big_font.render("Dino Escape", True, BLACK)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 100))
    pygame.draw.rect(screen, RED, play_button)
    play_text = font.render("PLAY", True, WHITE)
    screen.blit(play_text, (play_button.centerx - play_text.get_width() // 2,
                            play_button.centery - play_text.get_height() // 2))
    high_text = font.render(f"High Score: {high_score}", True, BLACK)
    screen.blit(high_text, (WIDTH // 2 - high_text.get_width() // 2, HEIGHT // 2 + 50))

def draw_game():
    screen.fill(SKY)
    pygame.draw.rect(screen, GREEN, (0, HEIGHT - 30, WIDTH, 30))

    # Dino
    screen.blit(dino_frames[dino_frame_index], (100, dino_rect.y))

    # Boost zones
    for zone in speed_boost_zones:
        if zone.right - camera_x > 0:
            pygame.draw.rect(screen, (255, 215, 0), (zone.x - camera_x, zone.y, zone.width, zone.height))

    for dragon in dragon_list:
        if dragon.right - camera_x > 0:
            screen.blit(dragon_img, (dragon.x - camera_x, dragon.y))

    for fb in fireballs:
        screen.blit(fireball_img, (fb.x - camera_x, fb.y))

    for coin in coins:
        screen.blit(coin_img, (coin.x - camera_x, coin.y))

    if dino_world_x >= castle_rect.left - WIDTH:
        screen.blit(castle_img, (castle_rect.x - camera_x, castle_rect.y))

    draw_hearts()
    score_text = font.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (WIDTH - 180, 10))

def draw_end(message):
    msg = big_font.render(message, True, RED if game_over else (0, 150, 0))
    screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, HEIGHT // 2 - 40))
    pygame.draw.rect(screen, RED, play_button)
    restart_text = font.render("RESTART", True, WHITE)
    screen.blit(restart_text, (play_button.centerx - restart_text.get_width() // 2,
                               play_button.centery - restart_text.get_height() // 2))

# Start game
running = True
reset_game()

while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if not game_active or game_over or win:
            if event.type == pygame.MOUSEBUTTONDOWN and play_button.collidepoint(event.pos):
                game_active = True
                reset_game()

        elif event.type == FIREBALL_TIMER and not game_over and not win:
            for dragon in dragon_list:
                if random.random() < 0.2:
                    fireball = fireball_img.get_rect(midtop=(dragon.centerx, dragon.bottom))
                    fireballs.append(fireball)

        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            if jumps < 2:
                dino_y_velocity = jump_strength if jumps == 0 else double_jump_strength
                jumps += 1

    if game_active and not game_over and not win:
        frame_timer += 1
        if frame_timer >= 5:
            dino_frame_index = (dino_frame_index + 1) % len(dino_frames)
            frame_timer = 0

        dino_y_velocity += gravity
        dino_rect.y += dino_y_velocity
        if dino_rect.bottom >= ground_y:
            dino_rect.bottom = ground_y
            dino_y_velocity = 0
            jumps = 0

        # Speed Boost Detection
        speed_boost_active = any(
            zone.colliderect(pygame.Rect(dino_world_x, dino_rect.y, dino_rect.width, dino_rect.height))
            for zone in speed_boost_zones
        )
        current_speed = boost_speed if speed_boost_active else base_speed

        # World movement
        dino_world_x += current_speed
        camera_x = dino_world_x - 100

        for fb in fireballs:
            fb.y += 5

        for fb in fireballs[:]:
            if pygame.Rect(dino_world_x, dino_rect.y, dino_rect.width, dino_rect.height).colliderect(fb):
                fireballs.remove(fb)
                lives -= 1
                if lives <= 0:
                    game_over = True
                    if score > high_score:
                        high_score = score
                        with open(high_score_file, "w") as f:
                            json.dump({"score": high_score}, f)

        for coin in coins[:]:
            if pygame.Rect(dino_world_x, dino_rect.y, dino_rect.width, dino_rect.height).colliderect(coin):
                coins.remove(coin)
                score += 1

        if dino_world_x + dino_rect.width >= castle_rect.left:
            win = True
            if score > high_score:
                high_score = score
                with open(high_score_file, "w") as f:
                    json.dump({"score": high_score}, f)

    if not game_active:
        draw_menu()
    elif game_over:
        draw_game()
        draw_end("Game Over!")
    elif win:
        draw_game()
        draw_end("You Win!")
    else:
        draw_game()

    pygame.display.flip()

pygame.quit()
